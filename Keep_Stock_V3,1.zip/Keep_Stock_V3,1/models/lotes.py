from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator

class Produto(CrudBase):
    table = "lotes"
    fields = [
        "numero_lote",
        "data_fabricacao",
        "data_validade",
        "quantidade_inicial",
        "quantidade_atual",
        "id_lote",
    ]

    def __init__(self, numero_lote, data_fabricacao, data_validade, quantidade_minima, quantidade, id_lote):
        self.numero_lote = numero_lote
        self.data_fabricacao = data_fabricacao
        self.data_validade = data_validade
        self.unidade_medida = unidade_medida
        self.quantidade_minima = quantidade_minima
        self.quantidade = quantidade
        self.id_lote = id_lote

    def validate(self):
        erros = [
            Validator.required(self.nome, "nome"),
            Validator.non_negative(self.quantidade, "quantidade"),
            Validator.non_negative(self.estoque_minimo, "estoque mínimo"),
            Validator.non_negative(self.preco_custo, "preço de custo"),
            Validator.non_negative(self.preco_venda, "preço de venda")
        ]
        return [erro for erro in erros if erro]  # ARRUMAR AS VALIDAÇÕES!

    @classmethod
    def low_stock(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM lotes WHERE quantidade <= quantidade_minima ORDER BY numero_lote"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def update_quantity(cls, id, nova_quantidade, connection=None):
        conexao = connection or Database.connect()
        cursor = conexao.cursor()
        try:
            sql = "UPDATE lote SET quantidade = %s WHERE id = %s"
            cursor.execute(sql, (nova_quantidade, id))
            if connection is None:
                conexao.commit()
            return cursor.rowcount
        except Exception:
            if connection is None:
                conexao.rollback()
            raise
        finally:
            cursor.close()
            if connection is None:
                conexao.close()

    @classmethod
    def has_related_records(cls, id): # LOTES TAMBÉM PASSAM POR MOTVIMENTAÇÕES, DEIXR ESTA FUNÇÃO CORRETA
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
                "SELECT COUNT(*) FROM movimentacao WHERE produto_id = %s",
                "SELECT COUNT(*) FROM pedido_movimentacao WHERE produto_id = %s"
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete(cls, id):
        produto = cls.find_by_id(id)
        if not produto:
            raise ValueError("Lote não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o lote porque ele possui pedidos ou movimentações vinculadas.")
        cls.delete(id)

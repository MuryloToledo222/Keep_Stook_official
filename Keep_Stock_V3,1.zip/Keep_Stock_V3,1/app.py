from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from models.produto import Produto
from models.movimentacao import Movimentacao
from models.pedido import Pedido
from core.validator import Validator
from flask_cors import CORS
from supabase import create_client, Client
import requests
import urllib.parse

app = Flask(__name__)
CORS(app)

# CONFIGURAÇÕES 
INVERTEXTO_TOKEN = "25384|j9ZTOhnY61kbOHY59QagFaLy86QvrCeY"
SUPABASE_URL = "https://gysiqyxpmlxmlolqzaqs.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd5c2lxeXhwbWx4bWxvbHF6YXFzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ5NjA3MDYsImV4cCI6MjA5MDUzNjcwNn0.Rst-gDutHxMCXUxGP2HYgRSnsUhip7tAevtsE9sWh4A" 

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

def to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def to_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default

def get_descarte_form():
    return {
        "id_lote": to_int(request.form.get("id_lote")) if request.form.get("id_lote") else None,
        "id_produto": to_int(request.form.get("id_produto")),
        "id_motivo": to_int(request.form.get("id_motivo")),
        "quantidade": to_int(request.form.get("quantidade")),
        "data_descarte": request.form.get("data_descarte"),
        "observacao": request.form.get("observacao", "").strip()
    }
 
def get_devolucao_form():
    return {
        "id_produto": to_int(request.form.get("id_produto")),
        "quantidade": to_int(request.form.get("quantidade")),
        "motivo": request.form.get("motivo", "").strip(),
        "data_devolucao": request.form.get("data_devolucao"),
        "observacao": request.form.get("observacao", "").strip()
    }
 
def get_funcionario_form():
    return {
        "id_usuario": to_int(request.form.get("id_usuario")),
        "cargo": request.form.get("cargo", "").strip(),
        "setor": request.form.get("setor", "").strip(),
        "salario": to_float(request.form.get("salario"))
    }
 
 
def get_sensor_form():
    return {
        "id_camara": to_int(request.form.get("id_camara")) if request.form.get("id_camara") else None,
        "id_area": to_int(request.form.get("id_area")) if request.form.get("id_area") else None,
        "tipo": request.form.get("tipo", "").strip()
    }
 


def get_produto_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "categoria": request.form.get("categoria", "").strip(),
        "descricao": request.form.get("descricao", "").strip(),
        "fabricante": request.form.get("fabricante", "").strip(),
        "valor_unitario": request.form.get("unidade_medida", "").strip(),
        "quantidade": to_int(request.form.get("quantidade")),
        "estoque_minimo": to_int(request.form.get("estoque_minimo")),
        "preco_custo": to_float(request.form.get("preco_custo")),
        "preco_venda": to_float(request.form.get("preco_venda"))
    }

def get_notificacao_form():
    return {
        "usuario_id": to_int(request.form.get("usuario_id")),
        "titulo": request.form.get("titulo", "").strip(),
        "mensagem": request.form.get("mensagem", "").strip(),
        "data": to_date(request.form.get("data", ""))
    }
 

def get_fornecedor_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "cnpj": to_int(request.form.get("cnpj", "")),
        "telefone": to_int(request.form.get("telefone", "")),
        "endereço": to_float(request.form.get("endereço", ""))
        "prod_fornecedor": request.form.get("produto_fornecedor", "").strip(),
    }

def get_pedido_form():
    return {
        "id_cliente": to_int(request.form.get("id_cliente")),
        "data_pedido": to_int(request.form.get("data_pedido"))
        "status_pedido": request.form.get("status_pedido", "").strip(),
        "data_prevista": to_int(request.form.get("quantidade")),
        
    }

def get_usuario_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "email": request.form.get("email", "").strip(),
        "senha": request.form.get("senha", "").strip(),
        "cpf": to_int(request.form.get("cpf")),
        "telefone": to_int(request.form.get("telefone")),
        "ativo": request.form.get("ativo", "").strip(),
        "criado_em": to_int(request.form.get("quantidade")),
    }


@app.route("/")
def index():
    produtos_baixo = Produto.low_stock()
    return render_template("index.html", produtos_baixo=produtos_baixo)




@app.route("/")
def index():
    fornecedor = create_fornecedor()
    return render_template("index.html", fornecedor=fornecedor)
 
 



#---------------------------------Fornecedores------------------------------------------------





@app.route("/fornecedor")
def produtos():
    return render_template("produtos.html", cliente=cliente.find_all(order_by="nome"))
 
 
@app.route("/fornecedor/novo")
def novo_fornecedor():
    return render_template("formulario_fornecedor.html", fornecedor=None)
 
 
@app.route("/fornecedor/salvar", methods=["POST"])  #
def salvar_fornecedor():
    dados = get_fornecedor_form()
    fornecedor = fornecedor(**dados)
 
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("formulario_fornecedor.html", fornecedor=dados)
 
    try:
        fornecedor.insert()
        flash("fornecedor cadastrado com sucesso.", "sucesso")
        return redirect(url_for("fornecedor"))
    except Exception as e:
        flash(f"Erro ao cadastrar fornecedor: {e}", "erro")
        return render_template("formulario_fornecedor.html", fornecedor=dados)
 
 
@app.route("/fornecedor/editar/<int:id>", methods=["GET"]) #
def editar_fornecedor(id):
    fornecedor = fornecedor.find_by_id(id)
    if not fornecedor:
        flash("fornecedor não encontrado.", "erro")
        return redirect(url_for("fornecedor"))
    return render_template("formulario_fornecedor.html", fornecedor=fornecedor)
 
 
@app.route("/fornecedor/atualizar/<int:id>", methods=["PUT"]) #
def atualizar_fornecedor(id):
    dados = get_fornecedor_form()
    fornecedor = fornecedor(**dados)
    erros = .validate()
 
    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("formulario_fornecedor.html", fornecedor=dados)
 
    try:
        if not fornecedor.find_by_id(id):
            flash("fornecedor não encontrado.", "erro")
            return redirect(url_for("fornecedor"))
 
        fornecedor.update(id)
        flash("fornecedor atualizado com sucesso.", "sucesso")
        return redirect(url_for("fornecedor"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar fornecedor: {e}", "erro")
        return render_template("formulario_fornecedor.html", fornecedor=dados)
 
 
@app.route("/fornecedor/excluir/<int:id>" methods=["DELETE"])#
def excluir_fornecedor(id):
    try:
        cliente.safe_delete(id)
        flash("cliente excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir fornecedor: {e}", "erro")
    return redirect(url_for("fornecedor"))
 



 
#---------------------------------Usuarios------------------------------------------------






@app.route('/cadastrar_user', methods=['POST']) #
def cadastrar():
    # Recebe os dados do JavaScript
    dados = request.get_json()
    
    print(f"Dados recebidos: {dados}")

    if not dados:
        return jsonify({"erro": "Dados não fornecidos"}), 400

    # Validações Básicas de Presença
    nome = dados.get('nome')
    email_cliente = dados.get('email', '').strip().lower()
    cpf_cliente = dados.get('cpf', '').strip()
    senha = dados.get('senha')

    erro_nome = Validator.required(nome, "Nome")
    if erro_nome:
        return jsonify({"erro": erro_nome}), 400

    if not Validator.validar_nome(dados):
        return jsonify({"erro": "O nome deve ter entre 1 e 120 caracteres."}), 400

    # Validação de E-mail 
    resultado_api_email = Validator.validar_email(email_cliente, INVERTEXTO_TOKEN)
    
    if not resultado_api_email:
        return jsonify({"erro": "Falha ao conectar com o validador de e-mail."}), 500
    
    
    if not resultado_api_email.get("valid_format") or not resultado_api_email.get("valid_mx"):
        return jsonify({"erro": "E-mail informado é inválido ou não existe."}), 400

    # Validação de CPF 
    
    resultado_api_cpf = Validator.validar_cpf(cpf_cliente, INVERTEXTO_TOKEN)
    
    if not resultado_api_cpf:
        return jsonify({"erro": "Falha técnica ao validar CPF. Tente novamente mais tarde."}), 500


    if not resultado_api_cpf.get("valid"):
        return jsonify({
            "erro": "CPF inválido.",
            "detalhes": "O número informado não passou na validação oficial."
        }), 400

    # Gravação no Supabase 
    try:
        novo_usuario = {
            "nome": nome,
            "email": email_cliente,
            "cpf": cpf_cliente,
            "senha": senha  
        }
        
        # Executa o insert no Supabase
        supabase.table("usuarios").insert(novo_usuario).execute()
        
        return jsonify({"mensagem": "Cadastro realizado com sucesso!"}), 201

    except Exception as e:
        print(f"Erro no Supabase: {e}")
        return jsonify({"erro": "Erro ao salvar no banco de dados. Verifique se o CPF ou E-mail já existem."}), 500

@app.route('/delete_conta', methods=['DELETE']) #
def excluir_log(id_usuario):
    try:
        Produto.safe_delete(id_usuario)
        flash("usuario excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir o ususario: {e}", "erro")
    return redirect(url_for("usuarios"))


@app.route('/login', methods=['PUT']) #
def login():
    try:
        dados = request.get_json()
        email_login = dados.get('email').strip().lower()
        senha_login = dados.get('senha')

        resposta = supabase.table("usuarios") \
            .select("*") \
            .eq("email", email_login) \
            .execute()

        # Verifica se o usuário existe mesmo
        if not resposta.data:
            return jsonify({"erro": "E-mail não cadastrado."}), 404
        
        usuario = resposta.data[0]

        # Verifica se a senha coincide também
        if usuario.get('senha') == senha_login:
            return jsonify({
                "mensagem": "Login realizado com sucesso!",
                "nome": usuario.get('nome')
            }), 200
        else:
            return jsonify({"erro": "Senha incorreta."}), 401

    # Se houver erro
    except Exception as e:
        print(f"Erro interno no Login: {e}")
        return jsonify({"erro": "Erro interno no servidor."}), 500






#---------------------------------Produtos------------------------------------------------





@app.route("/produtos")
def produtos():
    return render_template("produtos.html", produtos=Produto.find_all(order_by="nome"))


@app.route("/produto/novo")
def novo_produto():
    return render_template("formulario_produto.html", produto=None)


@app.route("/produto/salvar", methods=["POST"]) #
def salvar_produto():
    dados = get_produto_form()
    produto = Produto(**dados)
    erros = produto.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("formulario_produto.html", produto=dados)

    try:
        produto.insert()
        flash("Produto cadastrado com sucesso.", "sucesso")
        return redirect(url_for("produtos"))
    except Exception as e:
        flash(f"Erro ao cadastrar produto: {e}", "erro")
        return render_template("formulario_produto.html", produto=dados)


@app.route("/produto/ler/<int:id>", methods=["GET"]) #
def editar_produto(id_produto):
    produto = Produto.find_by_i(id_produto)
    if not produto:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("produtos"))
    return render_template("formulario_produto.html", produto=produto)


@app.route("/produto/atualizar/<int:id>", methods=["PUT"]) #
def atualizar_produto(id_produto):
    dados = get_produto_form()
    produto = Produto(**dados)
    erros = produto.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id_produto
        return render_template("formulario_produto.html", produto=dados)

    try:
        if not Produto.find_by_id(id_produto):
            flash("Produto não encontrado.", "erro")
            return redirect(url_for("produtos"))

        produto.update(id_produto)
        flash("Produto atualizado com sucesso.", "sucesso")
        return redirect(url_for("produtos"))
    except Exception as e:
        dados["id"] = id_produto
        flash(f"Erro ao atualizar produto: {e}", "erro")
        return render_template("formulario_produto.html", produto=dados)


@app.route("/produto/excluir/<int:id>", methods=["DELETE"]) #
def excluir_produto(id_produto):
    try:
        Produto.safe_delete(id_produto)
        flash("Produto excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir produto: {e}", "erro")
    return redirect(url_for("produtos"))





#---------------------------------Pedidos------------------------------------------------





@app.route("/pedidos")
def pedidos():
    return render_template("pedidos.html", pedidos=Pedido.find_all_with_product())


@app.route("/pedido/novo")
def novo_pedido():
    return render_template("formulario_pedido.html", pedido=None)


@app.route("/pedido/salvar", methods=["POST"]) #
def salvar_pedido():
    dados = get_pedido_form()
    produto = Produto.find_by_id(dados["produto_id"])
    pedido = Pedido(**dados)
    erros = pedido.validate()

    if not produto:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("produtos"))

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("formulario_pedido.html", produto=produto, tipo=dados["tipo"], pedido=dados)

    try:
        pedido.insert()
        flash("Pedido criado com sucesso.", "sucesso")
        return redirect(url_for("pedidos"))
    except Exception as e:
        flash(f"Erro ao criar pedido: {e}", "erro")
        return render_template("formulario_pedido.html", produto=produto, tipo=dados["tipo"], pedido=dados)


@app.route("/pedido/ler/<int:id>", methods=["GET"]) #
def ler_pedido(id_pedido):
    pedido = Pedido.find_by_i(id_pedido)
    if not pedido:
        flash("Pedido não encontrado.", "erro")
        return redirect(url_for("pedidos"))
    return render_template("formulario_pedido.html", pedido=pedido)

@app.route("/pedido/atualizar/<int:id>", methods=["PUT"]) #
def atualizar_pedido(id_pedido):
    dados = get_pedido_form()
    produto = Produto.find_by_id(dados["produto_id"])
    pedido = Pedido(**dados)
    erros = pedido.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id_pedido
        return render_template("formulario_pedido.html", produto=produto, tipo=dados["tipo"], pedido=dados)
    try:
        if not Pedido.find_by_id(id_pedido):
            flash("Pedido não encontrado.", "erro")
            return redirect(url_for("pedidos"))

        pedido.update(id_pedido)
        flash("Pedido atualizado com sucesso.", "sucesso")
        return redirect(url_for("pedidos"))
    except Exception as e:
        dados["id"] = id_pedido
        flash(f"Erro ao atualizar pedido: {e}", "erro")
        return render_template("formulario_pedido.html", produto=produto, tipo=dados["tipo"], pedido=dados)


@app.route("/pedido/cancelar/<int:id>", methods=["DELETE"]) #
def cancelar_pedido(id):
    try:
        mensagem = PedidoMovimentacao.cancelar(id)
        flash(mensagem, "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao cancelar pedido: {e}", "erro")
    return redirect(url_for("pedidos"))




#---------------------------------Descarte------------------------------------------------




@app.route("/descartes")
def descartes():
    return render_template("descartes.html", descartes=Descarte.find_all_with_details())
 
@app.route("/descarte/novo")
def novo_descarte():
    produtos_lista = Produto.find_all(order_by="nome")
    return render_template("formulario_descarte.html", produtos=produtos_lista, descarte=None)
 
@app.route("/descarte/salvar", methods=["POST"]) #
def salvar_descarte():
    dados = get_descarte_form()
    descarte = Descarte(**dados)
    erros = descarte.validate()
    if erros:
        for erro in erros: flash(erro, "erro")
        return redirect(url_for("novo_descarte"))
    try:
        descarte.insert()
        prod = Produto.find_by_id(dados["id_produto"])
        if prod:
            nova_qtd = prod.quantidade - dados["quantidade"]
            supabase.table("produtos").update({"quantidade": nova_qtd}).eq("id", dados["id_produto"]).execute()
        flash("Descarte registrado com sucesso.", "sucesso")
        return redirect(url_for("descartes"))
    except Exception as e:
        flash(f"Erro ao registrar descarte: {e}", "erro")
        return redirect(url_for("novo_descarte"))

@app.route("/descarte/ler/<int:id>", methods=["GET"]) #
def ler_descarte(id_descarte):
    descarte = Descartes.find_by_i(id_descarte)
    if not descarte:
        flash("Descarte não encontrado.", "erro")
        return redirect(url_for("descartes"))
    return render_template("formulario_descarte.html", descarte=descarte)

@app.route("/descarte/atualizar/<int:id>", methods=["PUT"]) #
def atualizar_descarte(id_descarte):
    dados = get_descarte_form()
    descarte = Descarte(**dados)
    erros = descarte.validate()

if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id_descarte
        return render_template("formulario_pedido.html", descarte=descarte)
    try:
        if not Descarte.find_by_id(id_descarte):
            flash("Descartes não encontrado.", "erro")
            return redirect(url_for("descartes"))

        descarte.update(id_descarte)
        flash("Descartes atualizado com sucesso.", "sucesso")
        return redirect(url_for("descartes"))
    except Exception as e:
        dados["id"] = id_descarte
        flash(f"Erro ao atualizar descartes: {e}", "erro")
        return render_template("formulario_descarte.html", descarte=descarte)


 
@app.route("/descarte/excluir/<int:id>", methods=["DELETE"]) #
def excluir_descarte(id):
    try:
        supabase.table("descartes").delete().eq("id_descarte", id).execute()
        flash("Descarte removido.", "sucesso")
    except Exception as e:
        flash(f"Erro ao excluir: {e}", "erro")
    return redirect(url_for("descartes"))
 
 
 


 #---------------------------------Devolução------------------------------------------------




@app.route("/devolucoes")
def devolucoes():
    return render_template("devolucoes.html", devolucoes=Devolucao.find_all_with_details())
 
@app.route("/devolucao/nova")
def nova_devolucao():
    produtos_lista = Produto.find_all(order_by="nome")
    return render_template("formulario_devolucao.html", produtos=produtos_lista, devolucao=None)
 
@app.route("/devolucao/salvar", methods=["POST"]) #
def salvar_devolucao():
    dados = get_devolucao_form()
    devolucao = Devolucao(**dados)
    erros = devolucao.validate()
    if erros:
        for erro in erros: flash(erro, "erro")
        return redirect(url_for("nova_devolucao"))
    try:
        devolucao.insert()
        prod = Produto.find_by_id(dados["id_produto"])
        if prod:
            nova_qtd = prod.quantidade + dados["quantidade"]
            supabase.table("produtos").update({"quantidade": nova_qtd}).eq("id", dados["id_produto"]).execute()
        flash("Devolução registrada e estoque atualizado.", "sucesso")
        return redirect(url_for("devolucoes"))
    except Exception as e:
        flash(f"Erro ao registrar devolução: {e}", "erro")
        return redirect(url_for("nova_devolucao"))

@app.route("/devolucao/ler/<int:id>", methods=["GET"]) #
def ler_devolucao(id_devolucao):
    devolucao = Devolucao.find_by_i(id_devolucao)
    if not devolucao:
        flash("Devoluções não encontrado.", "erro")
        return redirect(url_for("devolucao"))
    return render_template("formulario_devolucao.html", devolucao=devolucao)

@app.route("/devolucao/atualizar/<int:id>", methods=["PUT"]) #
def atualizar_devolucao(id_devolucao):
    dados = get_descarte_form()
    devolucao = Devolucao(**dados)
    erros = devolucao.validate()

if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id_devolucao
        return render_template("formulario_devolucao.html", devolucao=devolucao)
    try:
        if not Devolucao.find_by_id(id_descarte):
            flash("Devoluções não encontrado.", "erro")
            return redirect(url_for("devolucao"))

        devolucao.update(id_devolucao)
        flash("Devoluções atualizado com sucesso.", "sucesso")
        return redirect(url_for("devolucao"))
    except Exception as e:
        dados["id"] = id_devolucao
        flash(f"Erro ao atualizar devoluções: {e}", "erro")
        return render_template("formulario_devolucao.html", devolucao=devolucao)
 
@app.route("/devolucao/excluir/<int:id>", methods=["DELETE"]) #
def excluir_devolucao(id):
    try:
        supabase.table("devolucoes").delete().eq("id", id).execute()
        flash("Registro de devolução removido.", "sucesso")
    except Exception as e:
        flash(f"Erro ao excluir: {e}", "erro")
    return redirect(url_for("devolucoes"))
 





 #---------------------------------Funcionarios------------------------------------------------
 

 
 


@app.route("/funcionarios")
def funcionarios():
    lista_func = Funcionario.find_all_with_user_details()
    return render_template("funcionarios.html", funcionarios=lista_func)
 
@app.route("/funcionario/novo")
def novo_funcionario():
    usuarios_res = supabase.table("usuarios").select("id_usuario, nome").execute()
    return render_template("formulario_funcionario.html", usuarios=usuarios_res.data, funcionario=None)
 
@app.route("/funcionario/salvar", methods=["POST"]) #
def salvar_funcionario():
    dados = get_funcionario_form()
    funcionario = Funcionario(**dados)
    try:
        funcionario.insert()
        flash("Funcionário cadastrado com sucesso.", "sucesso")
        return redirect(url_for("funcionarios"))
    except Exception as e:
        flash(f"Erro ao cadastrar funcionário: {e}", "erro")
        return redirect(url_for("novo_funcionario"))
 
@app.route("/funcionario/ler/<int:id>", methods=["GET"]) #
def ler_funcionario(id_funcionario):
    funcionario = Funcionarios.find_by_i(id_funcionario)
    if not funcionario:
        flash("Funcionarios não encontrado.", "erro")
        return redirect(url_for("funcionario"))
    return render_template("formulario_funcionario.html", funcionario=funcionario)

@app.route("/funcionario/atualizar/<int:id>", methods=["PUT"]) #
def atualizar_funcionario(id_funcionario):
    dados = get_descarte_form()
    funcionario = Funcionarios(**dados)
    erros = funcionario.validate()

if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id_funcionario
        return render_template("formulario_funcionario.html", funcionario=funcionario)
    try:
        if not Funcionarios.find_by_id(id_funcionario):
            flash("Funcionarios não encontrado.", "erro")
            return redirect(url_for("funcionario"))

        funcionario.update(id_funcionario)
        flash("funcionario atualizado com sucesso.", "sucesso")
        return redirect(url_for("funcionario"))
    except Exception as e:
        dados["id"] = id_funcionario
        flash(f"Erro ao atualizar funcionarios: {e}", "erro")
        return render_template("formulario_funcionario.html", funcionario=funcionario)

@app.route("/funcionario/excluir/<int:id>", methods=["DELETE"]) #
def excluir_funcionario(id):
    try:
        supabase.table("funcionarios").delete().eq("id_funcionario", id).execute()
        flash("Funcionário removido com sucesso.", "sucesso")
    except Exception as e:
        flash(f"Erro ao excluir funcionário: {e}", "erro")
    return redirect(url_for("funcionarios"))
 
 

 #---------------------------------Notificações------------------------------------------------




@app.route("/notificacoes")
def notificacoes():
    return render_template("notificacoes.html", notificacoes=notificacoes.find_all(order_by="nome"))
 
 
@app.route("/notificacoes/novo")
def novo_notificacoes():
    return render_template("formulario_notificacoes.html", notificacoes=None)
 
 
@app.route("/notificacoes/salvar", methods=["POST"]) #
def salvar_notificacoes():
    dados = get_notificacoes_form()
    notificacoes = notificacoes(**dados)
 
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("formulario_notificacoes.html", notificacoes=dados)
 
    try:
        notificacoes.insert()
        flash("notificacoes cadastrado com sucesso.", "sucesso")
        return redirect(url_for("notificacoes"))
    except Exception as e:
        flash(f"Erro ao cadastrar notificacoes: {e}", "erro")
        return render_template("formulario_notificacoes.html", notificacoes=dados)
 
 
@app.route("/notificacoes/editar/<int:id>", methods=["GET"]) #
def editar_notificacoes(id):
    notificacoes = notificacoes.find_by_id(id)
    if not notificacoes:
        flash("notificacoes não encontrado.", "erro")
        return redirect(url_for("notificacoes"))
    return render_template("formulario_nootificacoes.html", notificacoes=notificacoes)
 
 
@app.route("/notificacoes/atualizar/<int:id>", methods=["PUT"]) #
def atualizar_notificacoes(id):
    dados = get_notificacoes_form()
    notificacoes = notificacoes(**dados)
    erros = .validate()
 
    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("formulario_notificacoes.html", notificacoes=dados)
 
    try:
        if not notificacoes.find_by_id(id):
            flash("notificacoes não encontrado.", "erro")
            return redirect(url_for("notificacoes"))
 
        notificacoes.update(id)
        flash("notificacoes atualizado com sucesso.", "sucesso")
        return redirect(url_for("notificacoes"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar notificacoes: {e}", "erro")
        return render_template("notificacoes_notificacoes.html", notificacoes=dados)
 
 
@app.route("/notificacoes/excluir/<int:id>" methods=["DELETE"]) #
def excluir_notificacoes(id):
    try:
        notificacoes.safe_delete(id)
        flash("notificacoes excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir notificacoes: {e}", "erro")
    return redirect(url_for("notificacoes"))
 
 

 

 #---------------------------------Sensores------------------------------------------------





 @app.route("/sensores")
def sensores():
    return render_template("sensores.html", sensores=Sensor.find_all_with_details())
 
@app.route("/sensor/novo")
def novo_sensor():
    camaras = supabase.table("camaras_frias").select("*").execute()
    areas = supabase.table("areas_estoque").select("*").execute()
    return render_template("formulario_sensor.html", camaras=camaras.data, areas=areas.data, sensor=None)
 
@app.route("/sensor/salvar", methods=["POST"]) #
def salvar_sensor():
    dados = get_sensor_form()
    sensor = Sensor(**dados)
    try:
        sensor.insert()
        flash("Sensor cadastrado com sucesso.", "sucesso")
        return redirect(url_for("sensores"))
    except Exception as e:
        flash(f"Erro ao cadastrar sensor: {e}", "erro")
        return redirect(url_for("novo_sensor"))
 
@app.route("/sensor/excluir/<int:id>", methods=["DELETE"]) #
def excluir_sensor(id):
    try:
        supabase.table("sensores").delete().eq("id_sensor", id).execute()
        flash("Sensor removido com sucesso.", "sucesso")
    except Exception as e:
        flash(f"Erro ao excluir sensor: {e}", "erro")
    return redirect(url_for("sensores"))
 
 
 

@app.route("/movimentacoes")
def movimentacoes():
    return render_template("movimentacoes.html", movimentacoes=Movimentacao.find_all_with_product())

if __name__ == "__main__":
    app.run(debug=True)

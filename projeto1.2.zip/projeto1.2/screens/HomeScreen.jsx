import React from 'react';

import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

export default function HomeScreen({ navigation }) {
  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}>
      {/* HEADER */}

      <View style={styles.header}>
        <View>
          <Text style={styles.welcome}>
            Bem-vindo
          </Text>

          <Text style={styles.userName}>
            Keep Stock 
          </Text>
        </View>

        <Image
          source={require('../assets/image/Keep.png')} 
          style={styles.logo}
        />

        <TouchableOpacity style={styles.notification}>
          <Ionicons
            name="notifications-outline"
            size={24}
            color="#ffffff"
          />
        </TouchableOpacity>
      </View>

      {/* DASHBOARD */}

      <View style={styles.balanceCard}>
        <View style={styles.cardalign}>
          <Text style={styles.balanceLabel}>
            Produtos em Estoque
          </Text>

          <Text style={styles.balanceLabel}>
            Produtos com estoque baixo
          </Text>
        </View>
        
        <View style={styles.cardalign}>
          <Text style={styles.balanceValue}>
            125
          </Text>

          <Text style={styles.redValue}>
            15
          </Text>
        </View>
        

        <View style={styles.balanceFooterUp}>
          <Ionicons
            name="trending-up"
            size={18}
            color="#22C55E"
          />

          <Text style={styles.balanceGrowth}>
            +12% este mês
          </Text>

          <View style={styles.balanceFooterdown}>
            <Ionicons
              name="trending-down"
              size={18}
              color="#EF4444"
            />

            <Text style={styles.balanceGrowth}>
              -5% este mês
            </Text>
          </View>
        </View>
        
      </View>
        

        
     

      {/* CARDS */}

      <View style={styles.cardsContainer}>
        <View style={styles.smallCard}>
          <View style={styles.iconBlue}>
            <Ionicons
              name="cube"
              size={24}
              color="#31ab9f"
            />
          </View>

          <Text style={styles.cardNumber}>
            125
          </Text>

          <Text style={styles.cardLabel}>
            Produtos
          </Text>
        </View>

        <View style={styles.smallCard}>
          <View style={styles.iconRed}>
            <Ionicons
              name="alert-circle"
              size={24}
              color="#EF4444"
            />
          </View>

          <Text style={styles.cardNumber}>
            8
          </Text>

          <Text style={styles.cardLabel}>
            Estoque Baixo
          </Text>
        </View>
      </View>

      {/* MENU */}

      <Text style={styles.sectionTitle}>
        Operações
      </Text>




      {/* PEDIDOS */}

      <View style={styles.backPed}>
        <Text style={styles.backTitle}>
            Entrada de Pedidos
        </Text>
        <View style={styles.pedidosList}>
        <View style={styles.IonColor}>
          <Ionicons
            name="person-outline"
            size={26}
            color={"#1f5751"}
        />
        </View>
          
        <Text style={styles.tableText}>
            Santa casa
        </Text>

        <Text style={styles.tableText}>
            Status: Aguardando
        </Text>
        <Text style={styles.tableText}>
            Data: 01/10/2026
        </Text>
        
      </View>
      

      <View style={styles.pedidosList}>
        <View style={styles.IonColor}>
          <Ionicons
            name="person-outline"
            size={26}
            color={"#1f5751"}
        />
        </View>

        <Text style={styles.tableText}>
            Drogaria Vida Nova
        </Text>

        <Text style={styles.tableText}>
            Status: Entregue
        </Text>
        <Text style={styles.tableText}>
            Data: 04/02/2026
        </Text>
      </View>

      <View style={styles.pedidosList}>
        <View style={styles.IonColor}>
          <Ionicons
            name="person-outline"
            size={26}
            color={"#1f5751"}
        />
        </View>

        <Text style={styles.tableText}>
            Droga Raia
        </Text>

        <Text style={styles.tableText}>
            Status: Prepara para Saída
        </Text>
        <Text style={styles.tableText}>
            Data: 17/06/2026
        </Text>
      </View>
      </View>
        <TouchableOpacity 
          style={styles.iae}
          onPress={() =>
          navigation.navigate('Pedidos')
        }>

        <Text style={styles.backTitle2}>
          Exibir mais pedidos
        </Text>

        </TouchableOpacity>

      {/* */}

      <View style={styles.bacPed}>
        <Text style={styles.backTitle}>
           Pedidos já entregues
        </Text>
        <View style={styles.pedidosList}>
        <View style={styles.IonColor}>
          <Ionicons
            name="person-outline"
            size={26}
            color={"#1f5751"}
        />
        </View>
          
        <Text style={styles.tableText}>
            Santa casa
        </Text>

        <Text style={styles.tableText}>
            Status: Aguardando
        </Text>
        <Text style={styles.tableText}>
            Data: 01/10/2026
        </Text>
        
      </View>
      

      </View>
        

        <Text style={styles.backTitle}>
         
        </Text>

       

      {/* viagem de tela */}
      

      <TouchableOpacity
        style={styles.actionButtonGreen}
        onPress={() =>
          navigation.navigate('Entrada')
        }
      >
        <View style={styles.buttonContent}>
          <Ionicons
            name="arrow-down-circle-outline"
            size={26}
            color="#fff"
          />

          <View>
            <Text style={styles.buttonTitle}>
              Entrada de Estoque
            </Text>

            <Text style={styles.buttonSubtitle}>
              Registrar novos produtos
            </Text>
          </View>
        </View>

        <Ionicons
          name="chevron-forward"
          size={22}
          color="#fff"
        />
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.actionButtonRed}
        onPress={() =>
          navigation.navigate('Saída')
        }
      >
        <View style={styles.buttonContent}>
          <Ionicons
            name="arrow-up-circle-outline"
            size={26}
            color="#fff"
          />

          <View>
            <Text style={styles.buttonTitle}>
              Saída de Estoque
            </Text>

            <Text style={styles.buttonSubtitle}>
              Registrar retirada
            </Text>
          </View>
        </View>

        <Ionicons
          name="chevron-forward"
          size={22}
          color="#fff"
        />
      </TouchableOpacity>

      {/* ATIVIDADES */}

      <Text style={styles.sectionTitle}>
        Atividades Recentes
      </Text>

      <View style={styles.activityCard}>
        <Ionicons
          name="checkmark-circle"
          size={22}
          color="#22C55E"
        />

        <Text style={styles.activityText}>
          Entrada de 10 Mouse Gamer
        </Text>
      </View>

      <View style={styles.activityCard}>
        <Ionicons
          name="remove-circle"
          size={22}
          color="#EF4444"
        />

        <Text style={styles.activityText}>
          Saída de 2 Monitores
        </Text>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
  },
  logo: {
    width: 280,
    height: 80,
    marginBottom: 20,
    resizeMode: 'contain',
    alignSelf: 'center'
  },

  header: {
    marginTop: 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  welcome: {
    color: '#042c28',
    fontSize: 15,
  },

  userName: {
    color: '#042c28',
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 3,
  },

  notification: {
    width: 50,
    height: 50,
    backgroundColor: '#1E293B',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  balanceCard: {
    backgroundColor:  '#148577',
    padding: 25,
    marginTop: 30,
    borderRadius: 22,
    
  },
  cardalign: {
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
  redValue: {
    color: "#de1616",
    fontSize: 42,
    fontWeight: 'bold',
    marginTop: 10,
    marginRight: 120
  },

  balanceLabel: {
    color: '#DBEAFE',
    fontSize: 16,
  },

  balanceValue: {
    color: '#fff',
    fontSize: 42,
    fontWeight: 'bold',
    marginTop: 10,
    marginLeft: 20
  },

  balanceFooterUp: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
  },
  balanceFooterdown: {
    marginLeft: 190,
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },

  balanceGrowth: {
    color: '#DCFCE7',
    marginLeft: 6,
    fontWeight: '600',
  },

  cardsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 25,
  },

  smallCard: {
    backgroundColor: '#042c28',
    width: '48%',
    borderRadius: 22,
    padding: 20,
  },

  iconBlue: {
    width: 50,
    height: 50,
    backgroundColor: '#1f5751',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  iconRed: {
    width: 50,
    height: 50,
    backgroundColor: '#450A0A',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  cardNumber: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 15,
  },

  cardLabel: {
    color: '#94A3B8',
    marginTop: 5,
  },

  sectionTitle: {
    color: '#053d38',
    fontSize: 22,
    fontWeight: 'bold',
    marginTop: 35,
    marginBottom: 18,
  },

  actionButtonBlue: {
    backgroundColor: '#2563EB',
    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  actionButtonGreen: {
    backgroundColor: '#16A34A',
    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  actionButtonRed: {
    backgroundColor: '#DC2626',
    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },

  buttonTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },

  buttonSubtitle: {
    color: '#E2E8F0',
    marginTop: 3,
    fontSize: 13,
  },

  activityCard: {
    backgroundColor: '#1E293B',
    borderRadius: 18,
    padding: 18,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },

  activityText: {
    color: '#fff',
    fontSize: 15,
  },
  pedidosList: {
    backgroundColor: '#056D56',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',

    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    marginLeft: 15,
    gap: 12,
    width: 530,
  
  },

  IonColor: {
    marginLeft: -10,
    width: 40,
    height: 40,
    borderRadius: 10,
    padding: 6,
    backgroundColor: '#fff'
    },

  tableText: {
    color: '#fff',
    fontSize: 18,
  },

  backPed: {
    backgroundColor: '#dfe6f0',
  },

  bacPed: {
    height: 260,
    marginTop: 55,
    backgroundColor: '#dfe6f0',
  },

  backTitle: {
    color: '#fff',
    backgroundColor: '#1E293B',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 25,
    borderRadius: 10,
    padding: 15,
  },

  backTitle2: {
    color: '#fff',
    backgroundColor: '#284169',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 25,
    borderRadius: 30,
    padding: 25,
  },

  TitleButton: {

    color: '#fff',
    backgroundColor: '#1E293B',
    fontSize: 20,

    marginBottom: 35,
    borderRadius: 10,
    padding: 10,
  }


}); 
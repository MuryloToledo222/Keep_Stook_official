import React, { useState } from 'react';

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

export default function ExitScreen() {
  const [quantity, setQuantity] =
    useState('');

  const currentStock = 15;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>
        Saída de Estoque
      </Text>

      <TouchableOpacity style={styles.qrButton}>
        <Ionicons
          name="qr-code-outline"
          size={28}
          color="#fff"
        />

        <Text style={styles.qrText}>
          Escanear Produto
        </Text>
      </TouchableOpacity>

      <View style={styles.productCard}>
        <Text style={styles.productName}>
          Mouse Gamer RGB
        </Text>

        <Text style={styles.stock}>
          Estoque Atual: {currentStock}
        </Text>
      </View>

      <Text style={styles.label}>
        Quantidade de Saída
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Digite a quantidade"
        placeholderTextColor="#94A3B8"
        keyboardType="numeric"
        value={quantity}
        onChangeText={setQuantity}
      />

      <View style={styles.resultCard}>
        <Text style={styles.resultText}>
          Estoque Restante
        </Text>

        <Text style={styles.resultValue}>
          {currentStock -
            Number(quantity || 0)}
        </Text>
      </View>

      <TouchableOpacity style={styles.confirmButton}>
        <Ionicons
          name="remove-circle"
          size={24}
          color="#fff"
        />

        <Text style={styles.confirmText}>
          Confirmar Saída
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },

  title: {
    color: '#000000',
    fontSize: 30,
    fontWeight: 'bold',
    marginTop: 50,
    marginBottom: 30,
  },

  qrButton: {
    backgroundColor: '#DC2626',
    height: 70,
    borderRadius: 22,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },

  qrText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },

  productCard: {
    backgroundColor: '#1f5751',
    borderRadius: 22,
    padding: 25,
    marginTop: 30,
  },

  productName: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
  },

  stock: {
    color: '#FCA5A5',
    marginTop: 10,
    fontWeight: 'bold',
  },

  label: {
    color: '#0e0c0c',
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 35,
    marginBottom: 15,
  },

  input: {
    backgroundColor: '#1f5751',
    height: 65,
    borderRadius: 18,
    paddingHorizontal: 20,
    color: '#fff',
    fontSize: 18,
  },

  resultCard: {
    backgroundColor: '#450A0A',
    borderRadius: 22,
    padding: 25,
    marginTop: 30,
    alignItems: 'center',
  },

  resultText: {
    color: '#FCA5A5',
    fontSize: 16,
  },

  resultValue: {
    color: '#fff',
    fontSize: 40,
    fontWeight: 'bold',
    marginTop: 10,
  },

  confirmButton: {
    backgroundColor: '#DC2626',
    height: 65,
    borderRadius: 22,
    marginTop: 35,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },

  confirmText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
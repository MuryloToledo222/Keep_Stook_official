import React from 'react';

import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

export default function Relatorio({ navigation }) {
    return (
        <ScrollView
            style={styles.container}
            showsVerticalScrollIndicator={false}
        >

            <View style={styles.begin
            }>
                <View>
                    <Text style={styles.updatrequest}>
                        Relatórios
                    </Text>
                </View>
            
                <Image
                    source={require('../assets/image/Keep.png')} 
                    style={styles.logo}
                />

            </View>

            <View style={styles.bodycard}>
                <View style={styles.cardtitle}>
                    
            </View>


        <View style={styles.containerTable}>
            <View style={styles.title1}>
            <Text style={styles.titleText1}>
                Alertas
            </Text>
        </View>
        {/* Cabeçalho */}
        <View style={styles.header}>
          <Text style={[styles.cell, styles.headerText]}>tipo de alerta:</Text>
          <Text style={[styles.cell, styles.headerText]}>id do remédio:</Text>
          <Text style={[styles.cell, styles.headerText]}>remédio:</Text>
          <Text style={[styles.cell, styles.headerText]}>detalhes:</Text>
        </View>

        {/* Linha 1 */}
        <View style={styles.row}>
          <Text style={styles.cell}>Temperatura</Text>
          <Text style={styles.cell}>2</Text>
          <Text style={styles.cell}>Ibuprofeno 500g</Text>
          <Text style={styles.cell4}>saiu de sua temp ideal. Foi de 1,5 para -2</Text>
        </View>

        {/* Linha 2 */}
        <View style={styles.row}>
          <Text style={styles.cell}>Validação</Text>
          <Text style={styles.cell}>3</Text>
          <Text style={styles.cell}>dorflex</Text>
          <Text style={styles.cell4}>13 semanas para passar da validade</Text>
        </View>
      </View>


        


      <View style={styles.histTable}>
        <View style={styles.title}>
            <Text style={styles.titleText}>
                Historico de Alteração
            </Text>
        </View>
        
        {/* Cabeçalho */}
        <View style={styles.header}>
          <Text style={[styles.cell, styles.headerText]}>Remedio</Text>
          <Text style={[styles.cell, styles.headerText]}>Temp</Text>
          <Text style={[styles.cell, styles.headerText]}>Armazem</Text>
          <Text style={[styles.cell, styles.headerText]}>Algterações</Text>
        </View>

        {/* Linha 1 */}
        <View style={styles.row}>
          <Text style={styles.cell}>Vacina</Text>
          <Text style={styles.cell}>-2</Text>
          <Text style={styles.cell}>Setor 1A</Text>
          <Text style={styles.cell4}>Setor 1B; temp 1,5</Text>
        </View>

        {/* Linha 2 */}
        <View style={styles.row}>
          <Text style={styles.cell}>Validação</Text>
          <Text style={styles.cell}>3</Text>
          <Text style={styles.cell}>dorflex</Text>
          <Text style={styles.cell4}>13 semanas para passar da validade</Text>
        </View>
      </View>





      </View>
      </ScrollView>

    )
}

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#dae0e8',
    paddingHorizontal: 20,
  },
  logo: {
    width: 200,
    height: 70,
    marginBottom: 20,
    resizeMode: 'contain',
    alignSelf: 'center'
  },
  perfil: {
    marginLeft: 50,
    marginTop: 10,
    width: 80,
    height: 60,
    resizeMode: 'contain',
    
  },

  begin: {
    marginTop: 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  allPosition: {
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
  updatrequest: {
    color: '#141a2c',
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 3,
  },
  pedidosList: {
    
    marginTop: 20,
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 10,
  },
  ClassestList: {
    flexDirection: 'row',
    gap: 40
  },
  ContentList: {

    width: 200,
    gap: 3,
  },
  imagePosition: {
    marginLeft: -50,

  },

  InfoList: {
    color: '#000000',
    marginBottom: 15,

    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 60,
    width: 200,
    backgroundColor: '#10b5ac',
    padding: 12,
    borderRadius: 15,
  },

  infoposition: {
    width: 270,
    alignItems: 'flex-end',
  },

  buttonTitle: {
    color: '#120c0c',
    fontSize: 16,
    
  },
  containerTable: {
    borderWidth: 2,
    backgroundColor: '#fff',
},
    histTable: {
        marginTop: 40,
        borderWidth: 2,
        backgroundColor: '#fff',
},
  container: { 
    padding: 10 
},
  header: {
    gap: 20, 
    flexDirection: 'row', 
    backgroundColor: '#f1f8ff', 
    paddingVertical: 10, 
    borderWidth: 1
},
  row: {  
    gap: 20,
    flexDirection: 'row', 
    borderWidth: 1, 
    borderBottomColor: '#000000', 
    paddingVertical: 10 
},
  cell: { 
    padding: 5,
    
    width: 100, 
    textAlign: 'center' 
},
    cell4:{
        width: 220
},
  headerText: { 
    fontWeight: 'bold' 
},
title1: {
    backgroundColor: '#1E293B',
    
},
titleText1: {
    color: '#fff',
    marginLeft: 190,
    fontSize: 25,
},
title: {
    backgroundColor: '#1E293B',
},
titleText: {
    fontSize: 25,
    color: '#fff',
    marginLeft: 150
},
});
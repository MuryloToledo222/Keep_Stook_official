import React, { useState } from 'react';

import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

export default function ProductsScreen() {
  const [search, setSearch] = useState('');

  const products = [
    {
      id: 1,
      name: 'Simeticona - Gaslev Max 250Mg 20 Cápsulas',
      category: 'Terapêutica',
      stock: 15,
      price:  57.21,
      image:
        'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcS-KkFEhW6YYD88O_Dnil3iSeqbF7KuHlMtS5WLWlt52TYlK7zzkh1z2m6G4XHGhiniKm1gBLuJg3INSgVvNloStVIGDsFMGA8h7HkehJQXi7Y9XhElofHvKA',
    },

    {
      id: 2,
      name: 'Ibupril 400mg 10 Cápsulas Gelatinosas Moles',
      category: 'Anti-inflamatórios',
      stock: 4,
      price:  27.82,
      image:
        'https://drogal.vtexassets.com/arquivos/ids/201581-1200-900?v=638399789851770000&width=1200&height=900&aspect=true',
    },

    {
      id: 3,
      name: 'Dorflex 24 Comprimidos',
      category: 'Analgésico e Relaxante Muscular',
      stock: 8,
      price: 19.52,
      image:
        'https://drogal.vtexassets.com/arquivos/ids/258785-1600-1200?v=638884419618030000&width=1600&height=1200&aspect=true',
    },

    {
      id: 4,
      name: 'Miorrelax 30 Comprimidos',
      category: 'Analgésico e Relaxante Muscular',
      stock: 2,
      price: 18.11,
      image:
        'https://drogal.vtexassets.com/arquivos/ids/273389-1200-900?v=639008872097100000&width=1200&height=900&aspect=true',
    },

    {
      id: 5,
      name: 'Estomazil Antiácido Sabor Abacaxi 20 Comprimidos Mastigáveis',
      category: 'Antiácido',
      stock: 10,
      price: 20.99,
      image:
        'https://drogal.vtexassets.com/arquivos/ids/248187-1200-900?v=638753361266530000&width=1200&height=900&aspect=true',
    },
  ];

  const filteredProducts = products.filter(
    (item) =>
      item.name
        .toLowerCase()
        .includes(search.toLowerCase()) ||
      item.category
        .toLowerCase()
        .includes(search.toLowerCase())
  );

  return (
    <View style={styles.container}>
      {/* HEADER */}

      <View style={styles.header}>
        <View>
          <Text style={styles.title}>
            Produtos
          </Text>

          <Text style={styles.subtitle}>
            Consulte os produtos cadastrados
          </Text>
        </View>

        <TouchableOpacity style={styles.filterButton}>
          <Ionicons
            name="options-outline"
            size={24}
            color="#fff"
          />
        </TouchableOpacity>
      </View>

      {/* PESQUISA */}

      <View style={styles.searchContainer}>
        <Ionicons
          name="search"
          size={22}
          color="#94A3B8"
        />

        <TextInput
          style={styles.searchInput}
          placeholder="Pesquisar produtos..."
          placeholderTextColor="#94A3B8"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* LISTA */}

      <FlatList
        data={filteredProducts}
        keyExtractor={(item) =>
          item.id.toString()
        }
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingBottom: 40,
        }}
        renderItem={({ item }) => (
          <View style={styles.card}>
            {/* IMAGEM */}

            <Image
              source={{ uri: item.image }}
              style={styles.image}
            />

            {/* CONTEÚDO */}

            <View style={styles.content}>
              {/* TOPO */}

              <View style={styles.topRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.name}>
                    {item.name}
                  </Text>

                  <Text style={styles.category}>
                    {item.category}
                  </Text>
                </View>

                <View
                  style={[
                    styles.stockBadge,
                    {
                      backgroundColor:
                        item.stock <= 5
                          ? '#7F1D1D'
                          : '#14532D',
                    },
                  ]}
                >
                  <Text style={styles.stockText}>
                    {item.stock}
                  </Text>
                </View>
              </View>

              {/* INFORMAÇÕES */}

              <View style={styles.infoRow}>
                <View style={styles.infoCard}>
                  <Ionicons
                    name="cube-outline"
                    size={18}
                    color="#16645c"
                  />

                  <Text style={styles.infoText}>
                    Estoque
                  </Text>
                </View>

                <View style={styles.infoCard}>
                  <Ionicons
                    name="pricetag-outline"
                    size={18}
                    color="#22C55E"
                  />

                  <Text style={styles.infoText}>
                    Produto
                  </Text>
                </View>
              </View>

              {/* PREÇO */}

              <View style={styles.bottomRow}>
                <Text style={styles.price}>
                  R$ {item.price}
                </Text>

                <Text
                  style={[
                    styles.stockStatus,
                    {
                      color:
                        item.stock <= 5
                          ? '#FCA5A5'
                          : '#86EFAC',
                    },
                  ]}
                >
                  {item.stock <= 5
                    ? 'Estoque baixo'
                    : 'Disponível'}
                </Text>
              </View>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
  },

  header: {
    marginTop: 55,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 25,
  },

  title: {
    color: '#0A4D46',
    fontSize: 32,
    fontWeight: 'bold',
  },

  subtitle: {
    color: '#94A3B8',
    marginTop: 5,
    fontSize: 15,
  },

  filterButton: {
    width: 52,
    height: 52,
    backgroundColor: '#053d38',
    borderRadius: 19,
    justifyContent: 'center',
    alignItems: 'center',
  },

  searchContainer: {
    backgroundColor: '#042c28',
    height: 62,
    borderRadius: 21,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    marginBottom: 25,
  },

  searchInput: {
    flex: 1,
    marginLeft: 10,
    color: '#fff',
    fontSize: 16,
  },

  card: {
    backgroundColor: '#0A4D46',
    borderRadius: 29,
    overflow: 'hidden',
    marginBottom: 22,
  },

  image: {
    width: '100%',
    height: 220,
  },

  content: {
    padding: 20,
  },

  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },

  name: {
    color: '#fff',
    fontSize: 21,
    fontWeight: 'bold',
  },

  category: {
    color: '#94A3B8',
    marginTop: 6,
    fontSize: 15,
  },

  stockBadge: {
    minWidth: 48,
    height: 48,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 12,
  },

  stockText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },

  infoRow: {
    flexDirection: 'row',
    marginTop: 18,
    gap: 12,
  },

  infoCard: {
    backgroundColor: '#053d38',
    borderRadius: 15,
    paddingHorizontal: 14,
    paddingVertical: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },

  infoText: {
    color: '#CBD5E1',
    marginLeft: 8,
    fontSize: 13,
  },

  bottomRow: {
    marginTop: 22,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  price: {
    color: '#fff',
    fontSize: 26,
    fontWeight: 'bold',
  },

  stockStatus: {
    fontSize: 14,
    fontWeight: '600',
  },
});
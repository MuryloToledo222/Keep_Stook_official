import React, { useState } from 'react';

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

export default function EntryScreen() {
  const [product, setProduct] =
    useState('Mouse Gamer RGB');

  const [code, setCode] =
    useState('PRD-94821');

  const [quantity, setQuantity] =
    useState('');

  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
    >
      {/* HEADER */}

      <View style={styles.header}>
        <Text style={styles.title}>
          Entrada de Estoque
        </Text>

        <Text style={styles.subtitle}>
          Registre produtos rapidamente
        </Text>
      </View>

      {/* QR CODE */}

      <TouchableOpacity style={styles.qrButton}>
        <View style={styles.qrContent}>
          <Ionicons
            name="qr-code-outline"
            size={32}
            color="#fff"
          />

          <View>
            <Text style={styles.qrTitle}>
              Ler QR Code
            </Text>

            <Text style={styles.qrSubtitle}>
              Escanear produto
            </Text>
          </View>
        </View>

        <Ionicons
          name="chevron-forward"
          size={22}
          color="#fff"
        />
      </TouchableOpacity>

      {/* PRODUTO */}

      <Text style={styles.sectionTitle}>
        Produto Encontrado
      </Text>

      <View style={styles.productCard}>
        <View style={styles.productIcon}>
          <Ionicons
            name="cube"
            size={28}
            color="#3B82F6"
          />
        </View>

        <View style={{ flex: 1 }}>
          <Text style={styles.productName}>
            {product}
          </Text>

          <Text style={styles.productCode}>
            Código: {code}
          </Text>

          <Text style={styles.productStock}>
            Estoque Atual: 15
          </Text>
        </View>
      </View>

      {/* QUANTIDADE */}

      <Text style={styles.sectionTitle}>
        Quantidade
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Digite a quantidade"
        placeholderTextColor="#94A3B8"
        keyboardType="numeric"
        value={quantity}
        onChangeText={setQuantity}
      />

      {/* RESUMO */}

      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>
          Resumo da Entrada
        </Text>

        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>
            Produto
          </Text>

          <Text style={styles.summaryValue}>
            {product}
          </Text>
        </View>

        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>
            Quantidade
          </Text>

          <Text style={styles.summaryValue}>
            {quantity || 0}
          </Text>
        </View>

        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>
            Estoque Final
          </Text>

          <Text style={styles.summaryValueGreen}>
            {15 + Number(quantity || 0)}
          </Text>
        </View>
      </View>

      {/* BOTÃO */}

      <TouchableOpacity style={styles.confirmButton}>
        <Ionicons
          name="checkmark-circle"
          size={24}
          color="#fff"
        />

        <Text style={styles.confirmText}>
          Confirmar Entrada
        </Text>
      </TouchableOpacity>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
  },

  header: {
    marginTop: 50,
  },

  title: {
    color: '#000000',
    fontSize: 30,
    fontWeight: 'bold',
  },

  subtitle: {
    color: '#94A3B8',
    marginTop: 5,
    fontSize: 15,
  },

  qrButton: {
    backgroundColor: '#2563EB',
    borderRadius: 25,
    padding: 22,
    marginTop: 30,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  qrContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },

  qrTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },

  qrSubtitle: {
    color: '#DBEAFE',
    marginTop: 3,
  },

  sectionTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 35,
    marginBottom: 15,
  },

  productCard: {
    backgroundColor: '#1f5751',
    borderRadius: 22,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },

  productIcon: {
    width: 65,
    height: 65,
    backgroundColor: '#1f5751',
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },

  productName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },

  productCode: {
    color: '#94A3B8',
    marginTop: 5,
  },

  productStock: {
    color: '#22C55E',
    marginTop: 8,
    fontWeight: 'bold',
  },

  input: {
    backgroundColor: '#1f5751',
    height: 65,
    borderRadius: 18,
    paddingHorizontal: 20,
    color: '#fff',
    fontSize: 18,
  },

  summaryCard: {
    backgroundColor: '#1f5751',
    borderRadius: 22,
    padding: 22,
    marginTop: 35,
  },

  summaryTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
  },

  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },

  summaryLabel: {
    color: '#94A3B8',
    fontSize: 15,
  },

  summaryValue: {
    color: '#fff',
    fontWeight: 'bold',
  },

  summaryValueGreen: {
    color: '#22C55E',
    fontWeight: 'bold',
  },

  confirmButton: {
    backgroundColor: '#16A34A',
    height: 65,
    borderRadius: 22,
    marginTop: 35,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },

  confirmText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
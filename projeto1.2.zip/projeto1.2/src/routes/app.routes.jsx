import React from 'react';

import {
  createNativeStackNavigator,
} from '@react-navigation/native-stack';

import {
  createBottomTabNavigator,
} from '@react-navigation/bottom-tabs';

import {
  createDrawerNavigator,
} from '@react-navigation/drawer';

import { Ionicons } from '@expo/vector-icons';

/* TELAS */


import LoginScreen from '../../screens/LoginScreen';
import HomeScreen from '../../screens/HomeScreen';
import ProductsScreen from '../../screens/ProductsScreen';
import PedidosScreen from '../../screens/PedidosScreen';
import EntryScreen from '../../screens/EntryScreen';
import ExitScreen from '../../screens/ExitScreen';
import HistoryScreen from '../../screens/HistoryScreen';
import SettingsScreen from '../../screens/SettingsScreen';
import ExibirMais from '../../screens/ExibirMais';
import Relatorio from '../../screens/Relatorio';
import Userconfig from '../../screens/Userconfig'


/* NAVIGATORS */

const Stack = createNativeStackNavigator();

const Tab = createBottomTabNavigator();

const Drawer = createDrawerNavigator();

/* BOTTOM TABS */

function BottomRoutes() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,

        tabBarStyle: {
          backgroundColor: '#1E293B',
          borderTopWidth: 0,
          height: 65,
          paddingBottom: 8,
          paddingTop: 5,
        },

        tabBarActiveTintColor: '#24b364',

        tabBarInactiveTintColor: '#9CA3AF',
      }}
    >
      {/* HOME */}

      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarIcon: ({
            color,
            size,
          }) => (
            <Ionicons
              name="home"
              size={size}
              color={color}
            />
          ),
        }}
      />

      {/* PRODUTOS */}

      <Tab.Screen
        name="Produtos"
        component={ProductsScreen}
        options={{
          tabBarIcon: ({
            color,
            size,
          }) => (
            <Ionicons
              name="cube"
              size={size}
              color={color}
            />
          ),
        }}
      />

      {/* HISTÓRICO */}

      <Tab.Screen
        name="Histórico"
        component={HistoryScreen}
        options={{
          tabBarIcon: ({
            color,
            size,
          }) => (
            <Ionicons
              name="time"
              size={size}
              color={color}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

/* DRAWER */

function DrawerRoutes() {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: '#1E293B',
        },

        headerTintColor: '#fff',

        drawerStyle: {
          backgroundColor: '#053d38',
          width: 280,
        },

        drawerActiveBackgroundColor:
          '#CBD5E1',
        

        drawerActiveTintColor: '#0C816A',

        drawerInactiveTintColor:
          '#CBD5E1',


       

        drawerLabelStyle: {
          marginLeft: -10,
          fontSize: 15,
        },
      }}
    >
      {/* DASHBOARD */}

      <Drawer.Screen
        name="Dashboard"
        component={BottomRoutes}
        options={{
          title: 'Início',

          drawerIcon: ({
            color,
            size,
          }) => (
            <Ionicons
              name="home-outline"
              size={size}
              color={color}
            />
          ),
        }}
      />

      {/* Fornecedor */}

      <Drawer.Screen
        name="Pedidos"
        component={PedidosScreen}
        options={{
          drawerIcon: ({
            color,
            size,
          }) => (
            <Ionicons
              name="cart-outline"
              size={size}
              color={color}
            />
          ),
        }}

        
      />

      <Drawer.Screen
        name="Relatório"
        component={Relatorio}
        options={{
          drawerIcon: ({
            color,
            size,
          }) => (
            <Ionicons
              name="alert-outline"
              size={size}
              color={color}
            />
          ),
        }}

        
      />
      {/* Userconfig */}

      <Drawer.Screen
        name="Config usuario"
        component={Userconfig}
        options={{
          drawerIcon: ({
            color,
            size,
          }) => (
            <Ionicons
              name="person-outline"
              size={size}
              color={color}
            />
          ),
        }}

        
      />

      {/* Fornecedor */}

      <Drawer.Screen
        name="Exibir Mais"
        component={ExibirMais}
        options={{
          drawerIcon: ({
            color,
            size,
          }) => (
            <Ionicons
              name="mail-outline"
              size={size}
              color={color}
            />
          ),
        }}
      />

        
      

      {/* ENTRADA */}

      <Drawer.Screen
        name="Entrada"
        component={EntryScreen}
        options={{
          drawerIcon: ({
            color,
            size,
          }) => (
            <Ionicons
              name="arrow-down-circle-outline"
              size={size}
              color={color}
            />
          ),
        }}
      />

      {/* SAÍDA */}

      <Drawer.Screen
        name="Saída"
        component={ExitScreen}
        options={{
          drawerIcon: ({
            color,
            size,
          }) => (
            <Ionicons
              name="arrow-up-circle-outline"
              size={size}
              color={color}
            />
          ),
        }}
      />

      {/* CONFIGURAÇÕES */}

      <Drawer.Screen
        name="Configurações"
        component={SettingsScreen}
        options={{
          drawerIcon: ({
            color,
            size,
          }) => (
            <Ionicons
              name="settings-outline"
              size={size}
              color={color}
            />
          ),
        }}
      />
    </Drawer.Navigator>
  );
}



/* ROTAS PRINCIPAIS */

export default function Routes() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      {/* LOGIN */}

      <Stack.Screen
        name="Login"
        component={LoginScreen}
      />

      {/* APP */}

      <Stack.Screen
        name="App"
        component={DrawerRoutes}
      />
    </Stack.Navigator>

      
    


   
      


  );
}